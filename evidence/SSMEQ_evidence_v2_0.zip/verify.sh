    #!/bin/sh
    # Simple parity check for SSMEQ evidence v2.0
    set -e

    if [ ! -f envelopes.jsonl ] || [ ! -f hashes.txt ] || [ ! -f checkpoint.txt ]; then
        echo "MISSING FILES: envelopes.jsonl / hashes.txt / checkpoint.txt"
        exit 1
    fi

    python - << 'EOF'
import hashlib, sys, os

def read_nonempty_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return [line.rstrip("\n") for line in f if line.strip()]

envelopes = read_nonempty_lines("envelopes.jsonl")
hashes    = read_nonempty_lines("hashes.txt")

ok = True

if len(envelopes) != len(hashes):
    print(f"COUNT MISMATCH: envelopes={len(envelopes)} hashes={len(hashes)}")
    ok = False
else:
    for idx, (line, expected) in enumerate(zip(envelopes, hashes), start=1):
        actual = hashlib.sha256(line.encode("utf-8")).hexdigest()
        if actual != expected:
            print(f"HASH MISMATCH at line {idx}")
            print(f"  expected={expected}")
            print(f"  actual  ={actual}")
            ok = False

# Check checkpoint HEAD
head = hashes[-1] if hashes else None
checkpoint_head = None
if os.path.exists("checkpoint.txt"):
    with open("checkpoint.txt", "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("HEAD="):
                checkpoint_head = line.strip().split("=", 1)[1]
                break

if head and checkpoint_head and head != checkpoint_head:
    print("CHECKPOINT MISMATCH:")
    print(f"  HEAD from hashes.txt     = {head}")
    print(f"  HEAD from checkpoint.txt = {checkpoint_head}")
    ok = False

if ok:
    print("ALL CHECKS PASSED")
    sys.exit(0)
else:
    sys.exit(1)
EOF
